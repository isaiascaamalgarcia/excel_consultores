<?php

	return [

	"button_new" => "Nuevo"
	
	];